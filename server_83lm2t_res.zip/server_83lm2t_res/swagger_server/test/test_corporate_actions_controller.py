# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.corporate_actions import CorporateActions  # noqa: E501
from swagger_server.models.entity_response import EntityResponse  # noqa: E501
from swagger_server.models.error_response_list import ErrorResponseList  # noqa: E501
from swagger_server.test import BaseTestCase


class TestCorporateActionsController(BaseTestCase):
    """CorporateActionsController integration test stubs"""

    def test_create_corporate_actions(self):
        """Test case for create_corporate_actions

        Create Corporate Action
        """
        body = CorporateActions()
        response = self.client.open(
            '/corporateActions',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_corporate_action(self):
        """Test case for delete_corporate_action

        Delete Corporate Action By Id
        """
        response = self.client.open(
            '/corporateActions/{id}'.format(id='id_example'),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_corporate_actions(self):
        """Test case for get_corporate_actions

        Get All Corporate Actions
        """
        response = self.client.open(
            '/corporateActions',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_corporate_actions_by_id(self):
        """Test case for get_corporate_actions_by_id

        Get Corporate Action By Id
        """
        response = self.client.open(
            '/corporateActions/{id}'.format(id='id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_update_corporate_action(self):
        """Test case for update_corporate_action

        Update Corporate Action By Id
        """
        body = CorporateActions()
        response = self.client.open(
            '/corporateActions/{id}'.format(id='id_example'),
            method='PUT',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
