'use strict';


/**
 * Create Corporate Action
 * Create Corporate Action
 *
 * body CorporateActions 
 * returns EntityResponse
 **/
exports.createCorporateActions = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "message" : "message",
  "statusCode" : "statusCode"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete Corporate Action By Id
 * Delete Corporate Action By Id
 *
 * id String Id of Corporate Action to get details
 * returns String
 **/
exports.deleteCorporateAction = function(id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get All Corporate Actions
 * Get All Corporate Actions
 *
 * returns List
 **/
exports.getCorporateActions = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "exDate" : "exDate",
  "affectedSecurities" : {
    "symbol" : "symbol",
    "name" : "name",
    "id" : "046b6c7f-0b8a-43b9-b35d-6489e6daee91",
    "actionDetails" : {
      "type" : "type",
      "splitRatio" : "splitRatio"
    },
    "ISIN" : "ISIN"
  },
  "recordDate" : "recordDate",
  "id" : "046b6c7f-0b8a-43b9-b35d-6489e6daee91",
  "type" : "type",
  "paymentDate" : "paymentDate",
  "issuer" : {
    "name" : "name",
    "tickerSymbol" : "tickerSymbol",
    "id" : "046b6c7f-0b8a-43b9-b35d-6489e6daee91",
    "ISIN" : "ISIN"
  }
}, {
  "exDate" : "exDate",
  "affectedSecurities" : {
    "symbol" : "symbol",
    "name" : "name",
    "id" : "046b6c7f-0b8a-43b9-b35d-6489e6daee91",
    "actionDetails" : {
      "type" : "type",
      "splitRatio" : "splitRatio"
    },
    "ISIN" : "ISIN"
  },
  "recordDate" : "recordDate",
  "id" : "046b6c7f-0b8a-43b9-b35d-6489e6daee91",
  "type" : "type",
  "paymentDate" : "paymentDate",
  "issuer" : {
    "name" : "name",
    "tickerSymbol" : "tickerSymbol",
    "id" : "046b6c7f-0b8a-43b9-b35d-6489e6daee91",
    "ISIN" : "ISIN"
  }
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get Corporate Action By Id
 * Get Corporate Action By Id
 *
 * id String Id of Corporate Action to get details
 * returns corporateActions
 **/
exports.getCorporateActionsById = function(id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "exDate" : "exDate",
  "affectedSecurities" : {
    "symbol" : "symbol",
    "name" : "name",
    "id" : "046b6c7f-0b8a-43b9-b35d-6489e6daee91",
    "actionDetails" : {
      "type" : "type",
      "splitRatio" : "splitRatio"
    },
    "ISIN" : "ISIN"
  },
  "recordDate" : "recordDate",
  "id" : "046b6c7f-0b8a-43b9-b35d-6489e6daee91",
  "type" : "type",
  "paymentDate" : "paymentDate",
  "issuer" : {
    "name" : "name",
    "tickerSymbol" : "tickerSymbol",
    "id" : "046b6c7f-0b8a-43b9-b35d-6489e6daee91",
    "ISIN" : "ISIN"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update Corporate Action By Id
 * Update Corporate Action By Id
 *
 * body CorporateActions 
 * id String Id of Corporate Action to get details
 * returns EntityResponse
 **/
exports.updateCorporateAction = function(body,id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "message" : "message",
  "statusCode" : "statusCode"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

