# AffectedSecurities

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**symbol** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**id** | **str** | affected Securities Id | [optional] 
**action_details** | [**ActionDetails**](ActionDetails.md) |  | [optional] 
**isin** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

